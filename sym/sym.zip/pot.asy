Version 4
SymbolType CELL
LINE Normal 16 104 16 112
LINE Normal 16 16 16 24
LINE Normal 27 24 5 24
LINE Normal 5 104 5 24
LINE Normal 5 104 27 104
LINE Normal 27 24 27 104
LINE Normal -11 54 5 64
LINE Normal -11 72 -11 54
LINE Normal 5 64 -11 72
LINE Normal -32 64 -11 64
TEXT 13 32 Left 0 1
TEXT 13 96 Left 0 3
TEXT 16 71 VLeft 1 lin
WINDOW 0 39 16 Left 2
WINDOW 39 124 39 Center 1
SYMATTR SpiceLine R=1Meg Val=50
SYMATTR Description Potentiometer
PIN 16 16 NONE 0
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN -32 64 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 16 112 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
